// This file is deprecated. See gameService.ts for the local logic.
export const generateQuiz = async () => { return [] };